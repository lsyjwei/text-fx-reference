# text glitch effect 

A Pen created on CodePen.

Original URL: [https://codepen.io/manaregr8/pen/GRzvYaM](https://codepen.io/manaregr8/pen/GRzvYaM).

